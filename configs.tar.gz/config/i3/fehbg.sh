#!/bin/sh -e

feh --randomize --bg-fill ~/Изображения/backgrounds/*
